var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');

var routes = require('./routes/index');

var app = express();

var fs = require('fs'),
    http = require('http'),
    url = require('url'),
    path = require('path');



var __dirname = "resources";

var swaggerJSDoc = require('swagger-jsdoc');

// swagger definition
var swaggerDefinition = {
  info: {
    title: 'API for Sample Node.JS App',
    version: '1.0.0',
    description: 'Node server impl for Node.JS sample app',
  },
  host: 'localhost:20001',
  basePath: '/services/nodejs',
};

// options for the swagger docs
var options = {
  // import swaggerDefinitions
  swaggerDefinition: swaggerDefinition,
  // path to the API docs
  apis: ['./routes/*.js'],
};

// initialize swagger-jsdoc
var swaggerSpec = swaggerJSDoc(options);

// serve swagger
app.get('/swagger.json', function(req, res) {
  res.setHeader('Content-Type', 'application/json');
  res.send(swaggerSpec);
});

app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));



module.exports = app;

app.use(express.static('public'));


app.get('/swagger.json', function(req, res) {
  console.log("-------- Request for Swgger file occured ---------------");
  res.setHeader('Content-Type', 'application/json');
  res.send(swaggerSpec);
});




app.get('/test', function (req, res) {
   console.log("Got a GET request for /test");
   res.send('Node.JS is up and running');
});

app.get('/movie', function (req, res) {
   console.log("Got a GET request for /movie");
   var file = path.resolve(__dirname,"movie.mp4");
    fs.stat(file, function(err, stats) {
      if (err) {
        if (err.code === 'ENOENT') {
          // 404 Error if file not found
          return res.sendStatus(404);
        }
      res.end(err);
      }

    var start = parseInt(0, 10);
    var total = stats.size;
    var end =  total - 1;
    var maxChunk = 1024 * 1024; // 1MB at a time

    if (chunksize > maxChunk) {
      var end = start + maxChunk - 1;
    }

    var chunksize = (end - start) + 1;

      res.writeHead(206, {
        "Content-Range": "bytes " + start + "-" + end + "/" + total,
        "Accept-Ranges": "bytes",
        "Content-Length": chunksize,
        "Content-Type": "video/mp4"
      });

      var stream = fs.createReadStream(file, { start: start, end: end })
        .on("open", function() {
          stream.pipe(res);
        }).on("error", function(err) {
          res.end(err);
        });
    });
});


var server = app.listen(3000, function () {

   var host = server.address().address
   var port = server.address().port

   console.log("Example app listening at http://%s:%s", host, port)
})

module.exports = app;
